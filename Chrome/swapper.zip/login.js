localStorage.setItem('token', `"${token.replace('"', '')}"`);
window.location.replace('https://discord.com/channels/@me');